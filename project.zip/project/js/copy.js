// check if there's local storage color option
let mainColors = localStorage.getItem("color_option");
console.log(mainColors);



if (mainColors !== null) {
   // console.log('local storage is not empty you set it on root now');
   // console.log(localStorage.getItem("color_option"));
   document.documentElement.style.setProperty('--main-color',localStorage.getItem("color_option"));

};


//toggle spin
document.querySelector(".toggle-settings .fa-gear").onclick = function() {

//toggle class fs-spinfor rotation on self
    this.classList.toggle("fa-spin");

//toggle class open on main settings box
document.querySelector(".settings-box").classList.toggle("open");
}; 



//switch colors
const colorlist = document.querySelectorAll(".colors-list li");

//loop on all list items

colorlist.forEach(li =>{
    //click on every list items

    li.addEventListener("click",(e) =>{

        console.log(e.target.dataset.color);

        //set color on root
        document.documentElement.style.setProperty('--main-color',e.target.dataset.color);

       // check for active class from all colors list item
      document.querySelectorAll(".colors-list li").forEach(element => {

        element.classList.remove("active");
    

      // Add Active class Element with Data-color === Locla Storage item 
      if (element.dataset.color === mainColors) {
        
         //Add active class

         element.classList.add("active");

      }
    });


        //set color on local storage
        localStorage.setItem("color_option",e.target.dataset.color);

      // Remove active from all childrens
      e.target.parentElement.querySelectorAll(".active").forEach(element => {

        element.classList.remove("active");
      });
      //Add Active class on self

      e.target.classList.add("active");

if (e.target.classList.background === 'yes'){

backgroundOption = true;

console.log(backgroundOption);
randomizeImags();

} else {
  backgroundOption = false;
  clearInterval(backgroundInterval);

}



   });

});
//switch Random background option
const randomBackEl= document.querySelectorAll(".random-backgrounds span");

//loop on all spans items

randomBackEl.forEach(span =>{

    //click on Every span

    span.addEventListener("click",(e) =>{

            // Remove active from all spans
            e.target.parentElement.querySelectorAll(".active").forEach(element => {
      
              element.classList.remove("active");
            });
            //Add Active class on self
      
            e.target.classList.add("active");

       // check for active class from all colors list item
      document.querySelectorAll(".colors-list li").forEach(element => {

        element.classList.remove("active");
      });
           //Add Active class on self

           e.target.classList.add("active");

        });
        
    if (e.target.dataset === 'yes') {
      //console.log("yes");
   backgroundOption = true;

    //console.log(backgroundOption);

      randomizeImags();


    } else {
    //console.log("no");

   backgroundOption = false;

    //console.log(backgroundOption);

   clearInterval(backgroundOption);

    }




   
     
     });
    

  
        
   



//select landing page element

let landingPage = document.querySelector(".landing-page");

//get array of image
let imgsArray = ["08.jpg","07.jpg","099.jpg"];

//Random Background option
let backgroundOption = true;

//Variable To Control The Interval
let backgroundInterval;

//Function To Randomize Imags
function randomizeImags() {
  if(backgroundOption === true){
    backgroundInterval = setInterval(() => {

      //change background image url
      
      let randomNumber = Math.floor(Math.random() * imgsArray.length);
      
      
      landingPage.style.backgroundImage = 'url("imgs/' + imgsArray[randomNumber] + '")';
     }, 1000)

  } 

}

randomizeImags();



//Get Random Number

