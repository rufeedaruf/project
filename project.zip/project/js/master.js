// check if there's local storage color option
let mainColors = localStorage.getItem("color_option");
console.log(mainColors);



if (mainColors !== null) {
   // console.log('local storage is not empty you set it on root now');
   // console.log(localStorage.getItem("color_option"));
 document.documentElement.style.setProperty('--main-color',localStorage.getItem("color_option"));
  // OR document.documentElement.style.setProperty('--main-color',mainColors);


   //chick for Active class from all colors list item
   document.querySelectorAll(".colors-list li").forEach(element => {

    element.classList.remove("active");

    // Active class on Element with Data color === localstorage item 
    if( (element.dataset.color === mainColors)){
      
      //Add active class

      element.classList.add("active");

    }
   }
   )
};
//Random Background option
let backgroundOption = true;

//Variable To Control The background Interval
let backgroundInterval;

//Chick there's local storage  random background item
let backgroundLocalItem = localStorage.getItem("background_option");

//Chick if Random background local storage not empty

//if (backgroundLocalItem !== null) {

 //console.log("not empty");

 //if (backgroundLocalItem === 'true') {

  // backgroundOption = true;

//} else {

 
 // backgroundOption = false;
   

  //}
 
  //Remove active from all spans

// document.querySelectorAll(".random-backgrounds span").forEach(element => {

  //  element.classList.remove("active");

 // });

 // if (backgroundLocalItem === 'true') {

 //  document.querySelectorAll(".random-backgrounds .yes").classList.add("active");

//} else {

  // document.querySelectorAll(".random-backgrounds .no").classList.add("active");

// }

//}







//Click on toggle settings Gear 

document.querySelector(".toggle-settings .fa-gear").onclick = function () {

  //toggle class fa-spin for rotation of or on self

  this.classList.toggle("fa-spin");

  //toggle class open on main settings Box

  document.querySelector(".settings-box").classList.toggle("open");
  
};


//switch colors
const colorsLi = document.querySelectorAll(".colors-list li");

//loop on all list items
colorsLi.forEach(li =>{
  //click on every list items

  li.addEventListener("click",(e) =>{

      //console.log(e.target.dataset.color);

      //set color on root
      document.documentElement.style.setProperty('--main-color',e.target.dataset.color);
      

     // Set color on local storage 

     localStorage.setItem("color_option",e.target.dataset.color);

 handleActive(e)
});
  });



  //Switch Random background option
  const randomBackEl = document.querySelectorAll(".random-backgrounds span");


//loop on all spans
randomBackEl.forEach(span => {
  //click on every list items

  span.addEventListener("click", (e) => { 

     //Romove active class from all childrens

     e.target.parentElement.querySelectorAll(".active").forEach(element => {

      element.classList.remove("active");
     });
    
    //Add active class on self
    e.target.classList.add("active");
    

    if (e.target.dataset.background === 'yes') {
      
      console.log("yse");


      backgroundOption = true;

      randomizeImags();

      localStorage.setItem("background_option", true);

    } else {
    console.log("no");

   backgroundOption = false;

    //console.log(backgroundOption);
    

   clearInterval(backgroundInterval);
     
  // localStorage.setItem("background_option", false);

    }

  });
});



//select landing page element

let landingPage = document.querySelector(".landing-page");

//get array of image
let imgsArray = ["08.jpg","07.jpg","099.jpg"];



//Function To Randomize Imags
function randomizeImags() {

  if (backgroundOption === true) {
    
    backgroundInterval = setInterval(() => {

   //Get random number
      let randomNumber = Math.floor(Math.random() * imgsArray.length);

         //change background image ur
      landingPage.style.backgroundImage = 'url("imgs/' + imgsArray[randomNumber] + '")';
     }, 1000)

  } 

}

randomizeImags();




// Select Skills Selector
let ourSkills = document.querySelector(".skills");

window.onscroll = function () {

  // Skills Offset Top
  let skillsOffsetTop = ourSkills.offsetTop;

  // Skills Outer Height
  let skillsOuterHeight = ourSkills.offsetHeight;

  // Window Height
  let windowHeight = this.innerHeight;

  // Window ScrollTop
  let windowScrollTop = this.pageYOffset;

  if (windowScrollTop > (skillsOffsetTop + skillsOuterHeight - windowHeight)) {

    let allSkills = document.querySelectorAll(".skill-box .skill-progress span");

    allSkills.forEach(skill => {

      skill.style.width = skill.dataset.progress;
    });
  }
};





//////////////////////////////////

//create the popup with image

let ourGallery = document.querySelectorAll(".gallery img");

ourGallery.forEach(img => {

  img.addEventListener('click', (e) => {

    //create Overly Element 

    let overlay = document.createElement("div");


    //Add class To Overlay

    overlay.className = 'popup-overlay';


    //Append Overlay To The Body
    
    document.body.appendChild(overlay);

    //Create the popup box


    let popupBox = document.createElement("div");

    //Add class for popup box

    popupBox.className = 'popup-box';
    if (img.alt !== null) {

      //Create Heading

      let imgHeading = document.createElement("h3");

      //Create text For Heading
      let imgText = document.createTextNode(img.alt);

      //Append the text for heading 

      imgHeading.appendChild(imgText);

      //Append the imgheading to the popup box

      popupBox.appendChild(imgHeading);



    }

    //Create the image

    let popupImage = document.createElement("img");

    //set image source

    popupImage.src = img.src;

    //Add image to popupBox

    popupBox.appendChild(popupImage);

    //Append The popup Box to body

    document.body.appendChild(popupBox);

    //create the close span
     let closeButton = document.createElement("span");

    // Create the close button text

    let closeButtonText = document.createTextNode("X");

    //aPPEND text TO CLOSE BUTTON

    closeButton.appendChild(closeButtonText);

   // Add class to closebutton

   closeButton.className = 'close-button';

   //Add close button to popup box
   popupBox.appendChild(closeButton);

  });

});

//close popup

document.addEventListener("click", function (e) {

  if (e.target.className == 'close-button') {

    //Remove current popup
    e.target.parentNode.remove();

    //Remove overlay

    document.querySelector(".popup-overlay").remove();


  }

});


//Select All Bullets
//من هنا لنهاية الselect linksممكن نستبدلها 
//نستبدلها بfunction ونشغلها مرة للBulletsومرة للlinks
const allBullets = document.querySelectorAll(".nav-bullets .bullet");
//هذا سنختصرة بالfunction
//allBullets.forEach (bullet =>{
  // bullet.addEventListener("click", (e) => {

   // document.querySelector(e.target.dataset.section).scrollIntoView({
    //  behavior: 'smooth'
    //});
   //});
//});

//Select All Links
const allLinks = document.querySelectorAll(".links a");
//هذا سنختصرة بالfunction
//allLinks.forEach (link =>{

 // link.addEventListener("click", (e) => {

   //لمنع الرابط الافتراضي
  // e.preventDefault();
   // document.querySelector(e.target.dataset.section).scrollIntoView({
     // behavior: 'smooth'
    //});
  // });
//});


function rufeeda(elements) {
  
elements.forEach (element=>{

  element.addEventListener("click", (e) => {

   //لمنع الرابط الافتراضي
   e.preventDefault();
   
    document.querySelector(e.target.dataset.section).scrollIntoView({

      behavior: 'smooth'
    });
   });
});
}

rufeeda(allBullets);
rufeeda(allLinks);

//function to add and remove active we use it with no & yes and another place
//Handle Active state

function handleActive (ev) {

  //Remove active from class all childrens
  
  ev.target.parentElement.querySelectorAll(".active").forEach(element => {

    element.classList.remove("active");

  });
//Add active class on self
ev.target.classList.add("active");
};

//Bullets Show & Hide                        
let bulletsSpan = document.querySelectorAll(".bullets-option span");
                                               
let bulletsContainer = document.querySelector(".nav-bullets");

let bulletsLocalItem = localStorage.getItem(".bullets-option");

if (bulletsLocalItem !== null) {
  bulletsSpan .forEach(span => {
    span.classList.remove("active");

  });
  if (bulletsLocalItem === 'block') {

    bulletsContainer.style.display = 'block';
    
    document.querySelector(".bullets-option .yes").classList.add("active");

  } else {
    bulletsContainer.style.display = 'none';
    
    document.querySelector(".bullets-option .no").classList.add("active");
    

  }

}
//loop on all spans
bulletsSpan.forEach(span => {
  //click on every list items

  span.addEventListener("click", (e) => { 

    if (span.dataset.display === 'show') {

      bulletsContainer.style.display = 'block';

      localStorage.setItem(".bullets-option" ,'block');
      

    } else {
      
      bulletsContainer.style.display = 'none';

      localStorage.setItem(".bullets-option" ,'none');



    }
    handleActive(e);
	
  });
});

document.querySelector(".reset-options").onclick = function () {
//we can use this way but all data  on localstorage will be remove it in all site 
  //localStorage.clear();


  //this way all datat on settings box will be remove like colors yes no hide and show
  localStorage.removeItem("color_option");
  localStorage.removeItem("background-option");
  localStorage.removeItem("bullets-option");



  window.location.reload();
}