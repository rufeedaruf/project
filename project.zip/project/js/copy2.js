// check if there's local storage color option
let mainColors = localStorage.getItem("color_option");
console.log(mainColors);



if (mainColors !== null) {
   // console.log('local storage is not empty you set it on root now');
   // console.log(localStorage.getItem("color_option"));
 document.documentElement.style.setProperty('--main-color',localStorage.getItem("color_option"));
  // OR document.documentElement.style.setProperty('--main-color',mainColors);


   //chick for Active class from all colors list item
   document.querySelectorAll(".colors-list li").forEach(element => {

    element.classList.remove("active");

    // Active class on Element with Data color === localstorage item 
    if( (element.dataset.color === mainColors)){
      
      //Add active class

      element.classList.add("active");

    }
   }
   )
};
//Random Background option
let backgroundOption = true;

//Variable To Control The background Interval
let backgroundInterval;

//Chick there's local storage  random background item
let backgroundLocalItem = localStorage.getItem("background_option");

//Chick if Random background local storage not empty

//if (backgroundLocalItem !== null) {

 //console.log("not empty");

 //if (backgroundLocalItem === 'true') {

  // backgroundOption = true;

//} else {

 
 // backgroundOption = false;
   

  //}
 
  //Remove active from all spans

// document.querySelectorAll(".random-backgrounds span").forEach(element => {

  //  element.classList.remove("active");

 // });

 // if (backgroundLocalItem === 'true') {

 //  document.querySelectorAll(".random-backgrounds .yes").classList.add("active");

//} else {

  // document.querySelectorAll(".random-backgrounds .no").classList.add("active");

// }

//}







//Click on toggle settings Gear 

document.querySelector(".toggle-settings .fa-gear").onclick = function () {

  //toggle class fa-spin for rotation of or on self

  this.classList.toggle("fa-spin");

  //toggle class open on main settings Box

  document.querySelector(".settings-box").classList.toggle("open");
  
};


//switch colors
const colorsLi = document.querySelectorAll(".colors-list li");

//loop on all list items
colorsLi.forEach(li =>{
  //click on every list items

  li.addEventListener("click",(e) =>{

      //console.log(e.target.dataset.color);

      //set color on root
      document.documentElement.style.setProperty('--main-color',e.target.dataset.color);
      

     // Set color on local storage 

     localStorage.setItem("color_option",e.target.dataset.color);

     //Romove active class from all childrens
     e.target.parentElement.querySelectorAll(".active").forEach(element => {

      element.classList.remove("active");
     });
    
    //Add active class on self
    e.target.classList.add("active");
   
  });



  //Switch Random background option
  const randomBackEl = document.querySelectorAll(".random-backgrounds span");


//loop on all spans
randomBackEl.forEach(span => {
  //click on every list items

  span.addEventListener("click", (e) => { 

     //Romove active class from all childrens

     e.target.parentElement.querySelectorAll(".active").forEach(element => {

      element.classList.remove("active");
     });
    
    //Add active class on self
    e.target.classList.add("active");
    

    if (e.target.dataset.background === 'yes') {
      
      console.log("yse");


      backgroundOption = true;

      randomizeImags();

      localStorage.setItem("background_option", true);

    } else {
    console.log("no");

   backgroundOption = false;

    //console.log(backgroundOption);

   clearInterval(backgroundInterval);
     
  // localStorage.setItem("background_option", false);

    }

  });
});

   






//select landing page element

let landingPage = document.querySelector(".landing-page");

//get array of image
let imgsArray = ["08.jpg","07.jpg","099.jpg"];



//Function To Randomize Imags
function randomizeImags() {

  if (backgroundOption === true) {
    
    backgroundInterval = setInterval(() => {

   //Get random number
      let randomNumber = Math.floor(Math.random() * imgsArray.length);

         //change background image url
      landingPage.style.backgroundImage = 'url("imgs/' + imgsArray[randomNumber] + '")';
     }, 1000)

  } 

}

randomizeImags();

});





//Select Skills Selector
let ourSkills = document.querySelector(".skills");

window.onscroll = function () {

  //Skills offset top
  let skillsOffsetTop = ourSkills.offsetTop;

  //Skills OUter Height

  let skillsOuterHeight = ourSkills.offsetHeight;
  //Window Height

  let windowHeight = this.innerHeight;

   //his.console.log(skillsOuterHeight);

  //Window ScrollTop
  let windowScrollTop = this.pageYOffset;

  if (windowScrollTop > (skillsOffsetTop + skillsOuterHeight - windowHeight)) {

    let allSkills = document.querySelectorAll(".skill-box skill-progress span");

     allSkills.forEach(skill => {

      skill.style.width = skill.dataset.progress;

    });
  }
};
//////////////////////////////////

//create the popup with image

let ourGallery = document.querySelectorAll(".gallery img");

ourGallery.forEach(img => {
  img.addEventListener('click', (e) => {

    //create Overly Element 

    let overlay = document.createElement("div");


    //Add class To Overlay

    overlay.className = 'popup-overlay';


    //Append Overlay To The Body
    
    document.body.appendChild(overlay);

    //Create the popup box


    let popupBox = document.createElement("div");

    //Add class for popup box

    popupBox.className = 'popup-box';

    //Create the image

    let popupImage = document.createElement("img");

    //set image source

    popupImage.src = img.src;

    //Add image to popupBox

    popupBox.appendChild(popupImage);

    //Append The popup Box to body

    document.body.appendChild(popupBox);


  });

});


